package com.kaf.apachekafka.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.kaf.apachekafka.services.KafkaProducer;
import com.kaf.apachekafka.storage.MessageStorage;

@RestController
@RequestMapping(value="/jsa/kafka")
public class WebRestController {
	
	@Autowired
	KafkaProducer producer;
	
	Map ls=new HashMap();
	String messages="";
	@Autowired
	MessageStorage storage;
	
	@GetMapping(value="/producer")
	public String producer(@RequestParam("data")String data){
		producer.send(data);
		System.out.println(data);
		return "Produced Data Successfully";
	}
	
	@GetMapping(value="/consumer")
	public String getAllRecievedMessage(){

		messages=messages.concat(storage.toString());
		
		System.out.println(messages);
		return "received"+messages;
	}
}
