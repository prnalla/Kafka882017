package com.kaf.apachekafka.storage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class MessageStorage {

	public void put(String message) {

		PreparedStatement preparedStatement = null;

		try {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			Connection conn = DriverManager.getConnection(
					"jdbc:mysql://localhost:3307/test", "root", "mysql");
			String sql = "INSERT INTO kafka values (?)";
			preparedStatement = conn.prepareStatement(sql);

			preparedStatement.setString(1, message);

			preparedStatement.executeUpdate();

			System.out.println("Record is inserted into  table!");

		} catch (SQLException e) {

			e.printStackTrace();

		}

	}

	public String toString() {
		StringBuffer info = new StringBuffer();
		// storage.forEach(msg->info.append(msg).append("<br/>"));
		return info.toString();
	}

}
